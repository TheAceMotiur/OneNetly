import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/drive-accounts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAllQuotas
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
export const syncAllQuotas = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncAllQuotas.url(options),
    method: 'post',
})

syncAllQuotas.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts/sync-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAllQuotas
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
syncAllQuotas.url = (options?: RouteQueryOptions) => {
    return syncAllQuotas.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAllQuotas
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
syncAllQuotas.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncAllQuotas.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAllQuotas
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
    const syncAllQuotasForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: syncAllQuotas.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAllQuotas
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
        syncAllQuotasForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: syncAllQuotas.url(options),
            method: 'post',
        })
    
    syncAllQuotas.form = syncAllQuotasForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
export const testCredentials = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testCredentials.url(options),
    method: 'post',
})

testCredentials.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts/test-credentials',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
testCredentials.url = (options?: RouteQueryOptions) => {
    return testCredentials.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
testCredentials.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testCredentials.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
    const testCredentialsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: testCredentials.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
        testCredentialsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: testCredentials.url(options),
            method: 'post',
        })
    
    testCredentials.form = testCredentialsForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
export const test = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

test.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts/{driveAccount}/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
test.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return test.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
test.post = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
    const testForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: test.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
        testForm.post = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: test.url(args, options),
            method: 'post',
        })
    
    test.form = testForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncQuota
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
export const syncQuota = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncQuota.url(args, options),
    method: 'post',
})

syncQuota.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts/{driveAccount}/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncQuota
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
syncQuota.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return syncQuota.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncQuota
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
syncQuota.post = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncQuota.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncQuota
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
    const syncQuotaForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: syncQuota.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncQuota
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
        syncQuotaForm.post = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: syncQuota.url(args, options),
            method: 'post',
        })
    
    syncQuota.form = syncQuotaForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::updatePriority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
export const updatePriority = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePriority.url(args, options),
    method: 'patch',
})

updatePriority.definition = {
    methods: ["patch"],
    url: '/admin/drive-accounts/{driveAccount}/priority',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::updatePriority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
updatePriority.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return updatePriority.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::updatePriority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
updatePriority.patch = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePriority.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::updatePriority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
    const updatePriorityForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePriority.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::updatePriority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
        updatePriorityForm.patch = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePriority.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePriority.form = updatePriorityForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
export const update = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/drive-accounts/{driveAccount}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
update.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return update.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
update.put = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
    const updateForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
        updateForm.put = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggleStatus
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
export const toggleStatus = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

toggleStatus.definition = {
    methods: ["patch"],
    url: '/admin/drive-accounts/{driveAccount}/toggle',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggleStatus
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
toggleStatus.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return toggleStatus.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggleStatus
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
toggleStatus.patch = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggleStatus
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
    const toggleStatusForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggleStatus
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
        toggleStatusForm.patch = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleStatus.form = toggleStatusForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
export const destroy = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/drive-accounts/{driveAccount}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
destroy.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return destroy.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
destroy.delete = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
    const destroyForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
        destroyForm.delete = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AdminDriveAccountController = { index, store, syncAllQuotas, testCredentials, test, syncQuota, updatePriority, update, toggleStatus, destroy }

export default AdminDriveAccountController