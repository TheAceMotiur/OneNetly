import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/settings/monetization',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updatePaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
export const updatePaypal = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePaypal.url(options),
    method: 'put',
})

updatePaypal.definition = {
    methods: ["put"],
    url: '/admin/settings/monetization/paypal',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updatePaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
updatePaypal.url = (options?: RouteQueryOptions) => {
    return updatePaypal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updatePaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
updatePaypal.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePaypal.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updatePaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
    const updatePaypalForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePaypal.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updatePaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
        updatePaypalForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePaypal.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePaypal.form = updatePaypalForm
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updateAdsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
export const updateAdsense = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateAdsense.url(options),
    method: 'put',
})

updateAdsense.definition = {
    methods: ["put"],
    url: '/admin/settings/monetization/adsense',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updateAdsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
updateAdsense.url = (options?: RouteQueryOptions) => {
    return updateAdsense.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updateAdsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
updateAdsense.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateAdsense.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updateAdsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
    const updateAdsenseForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateAdsense.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::updateAdsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
        updateAdsenseForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateAdsense.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateAdsense.form = updateAdsenseForm
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::testPaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
export const testPaypal = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testPaypal.url(options),
    method: 'post',
})

testPaypal.definition = {
    methods: ["post"],
    url: '/admin/settings/monetization/paypal/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::testPaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
testPaypal.url = (options?: RouteQueryOptions) => {
    return testPaypal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::testPaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
testPaypal.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testPaypal.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::testPaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
    const testPaypalForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: testPaypal.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::testPaypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
        testPaypalForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: testPaypal.url(options),
            method: 'post',
        })
    
    testPaypal.form = testPaypalForm
const MonetizationSettingsController = { edit, updatePaypal, updateAdsense, testPaypal }

export default MonetizationSettingsController