import AdminDashboardController from './AdminDashboardController'
import AdminUserController from './AdminUserController'
import AdminDriveAccountController from './AdminDriveAccountController'
import SubscriptionPlanController from './SubscriptionPlanController'
import SubscriptionController from './SubscriptionController'
import MonetizationSettingsController from './MonetizationSettingsController'
const Admin = {
    AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
AdminUserController: Object.assign(AdminUserController, AdminUserController),
AdminDriveAccountController: Object.assign(AdminDriveAccountController, AdminDriveAccountController),
SubscriptionPlanController: Object.assign(SubscriptionPlanController, SubscriptionPlanController),
SubscriptionController: Object.assign(SubscriptionController, SubscriptionController),
MonetizationSettingsController: Object.assign(MonetizationSettingsController, MonetizationSettingsController),
}

export default Admin