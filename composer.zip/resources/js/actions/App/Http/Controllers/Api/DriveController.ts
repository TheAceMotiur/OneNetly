import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DriveController::index
 * @see app/Http/Controllers/Api/DriveController.php:26
 * @route '/api/drive'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/drive',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DriveController::index
 * @see app/Http/Controllers/Api/DriveController.php:26
 * @route '/api/drive'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::index
 * @see app/Http/Controllers/Api/DriveController.php:26
 * @route '/api/drive'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DriveController::index
 * @see app/Http/Controllers/Api/DriveController.php:26
 * @route '/api/drive'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::index
 * @see app/Http/Controllers/Api/DriveController.php:26
 * @route '/api/drive'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::index
 * @see app/Http/Controllers/Api/DriveController.php:26
 * @route '/api/drive'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DriveController::index
 * @see app/Http/Controllers/Api/DriveController.php:26
 * @route '/api/drive'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\DriveController::storage
 * @see app/Http/Controllers/Api/DriveController.php:299
 * @route '/api/drive/storage'
 */
export const storage = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: storage.url(options),
    method: 'get',
})

storage.definition = {
    methods: ["get","head"],
    url: '/api/drive/storage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DriveController::storage
 * @see app/Http/Controllers/Api/DriveController.php:299
 * @route '/api/drive/storage'
 */
storage.url = (options?: RouteQueryOptions) => {
    return storage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::storage
 * @see app/Http/Controllers/Api/DriveController.php:299
 * @route '/api/drive/storage'
 */
storage.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: storage.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DriveController::storage
 * @see app/Http/Controllers/Api/DriveController.php:299
 * @route '/api/drive/storage'
 */
storage.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: storage.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::storage
 * @see app/Http/Controllers/Api/DriveController.php:299
 * @route '/api/drive/storage'
 */
    const storageForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: storage.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::storage
 * @see app/Http/Controllers/Api/DriveController.php:299
 * @route '/api/drive/storage'
 */
        storageForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: storage.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DriveController::storage
 * @see app/Http/Controllers/Api/DriveController.php:299
 * @route '/api/drive/storage'
 */
        storageForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: storage.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    storage.form = storageForm
/**
* @see \App\Http\Controllers\Api\DriveController::allFolders
 * @see app/Http/Controllers/Api/DriveController.php:227
 * @route '/api/drive/folders'
 */
export const allFolders = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: allFolders.url(options),
    method: 'get',
})

allFolders.definition = {
    methods: ["get","head"],
    url: '/api/drive/folders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DriveController::allFolders
 * @see app/Http/Controllers/Api/DriveController.php:227
 * @route '/api/drive/folders'
 */
allFolders.url = (options?: RouteQueryOptions) => {
    return allFolders.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::allFolders
 * @see app/Http/Controllers/Api/DriveController.php:227
 * @route '/api/drive/folders'
 */
allFolders.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: allFolders.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DriveController::allFolders
 * @see app/Http/Controllers/Api/DriveController.php:227
 * @route '/api/drive/folders'
 */
allFolders.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: allFolders.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::allFolders
 * @see app/Http/Controllers/Api/DriveController.php:227
 * @route '/api/drive/folders'
 */
    const allFoldersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: allFolders.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::allFolders
 * @see app/Http/Controllers/Api/DriveController.php:227
 * @route '/api/drive/folders'
 */
        allFoldersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: allFolders.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DriveController::allFolders
 * @see app/Http/Controllers/Api/DriveController.php:227
 * @route '/api/drive/folders'
 */
        allFoldersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: allFolders.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    allFolders.form = allFoldersForm
/**
* @see \App\Http\Controllers\Api\DriveController::createFolder
 * @see app/Http/Controllers/Api/DriveController.php:68
 * @route '/api/drive/folders'
 */
export const createFolder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createFolder.url(options),
    method: 'post',
})

createFolder.definition = {
    methods: ["post"],
    url: '/api/drive/folders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DriveController::createFolder
 * @see app/Http/Controllers/Api/DriveController.php:68
 * @route '/api/drive/folders'
 */
createFolder.url = (options?: RouteQueryOptions) => {
    return createFolder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::createFolder
 * @see app/Http/Controllers/Api/DriveController.php:68
 * @route '/api/drive/folders'
 */
createFolder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createFolder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::createFolder
 * @see app/Http/Controllers/Api/DriveController.php:68
 * @route '/api/drive/folders'
 */
    const createFolderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: createFolder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::createFolder
 * @see app/Http/Controllers/Api/DriveController.php:68
 * @route '/api/drive/folders'
 */
        createFolderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: createFolder.url(options),
            method: 'post',
        })
    
    createFolder.form = createFolderForm
/**
* @see \App\Http\Controllers\Api\DriveController::upload
 * @see app/Http/Controllers/Api/DriveController.php:99
 * @route '/api/drive/upload'
 */
export const upload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

upload.definition = {
    methods: ["post"],
    url: '/api/drive/upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DriveController::upload
 * @see app/Http/Controllers/Api/DriveController.php:99
 * @route '/api/drive/upload'
 */
upload.url = (options?: RouteQueryOptions) => {
    return upload.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::upload
 * @see app/Http/Controllers/Api/DriveController.php:99
 * @route '/api/drive/upload'
 */
upload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::upload
 * @see app/Http/Controllers/Api/DriveController.php:99
 * @route '/api/drive/upload'
 */
    const uploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upload.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::upload
 * @see app/Http/Controllers/Api/DriveController.php:99
 * @route '/api/drive/upload'
 */
        uploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upload.url(options),
            method: 'post',
        })
    
    upload.form = uploadForm
/**
* @see \App\Http\Controllers\Api\DriveController::backupUpload
 * @see app/Http/Controllers/Api/DriveController.php:122
 * @route '/api/drive/backup-upload'
 */
export const backupUpload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: backupUpload.url(options),
    method: 'post',
})

backupUpload.definition = {
    methods: ["post"],
    url: '/api/drive/backup-upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DriveController::backupUpload
 * @see app/Http/Controllers/Api/DriveController.php:122
 * @route '/api/drive/backup-upload'
 */
backupUpload.url = (options?: RouteQueryOptions) => {
    return backupUpload.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::backupUpload
 * @see app/Http/Controllers/Api/DriveController.php:122
 * @route '/api/drive/backup-upload'
 */
backupUpload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: backupUpload.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::backupUpload
 * @see app/Http/Controllers/Api/DriveController.php:122
 * @route '/api/drive/backup-upload'
 */
    const backupUploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: backupUpload.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::backupUpload
 * @see app/Http/Controllers/Api/DriveController.php:122
 * @route '/api/drive/backup-upload'
 */
        backupUploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: backupUpload.url(options),
            method: 'post',
        })
    
    backupUpload.form = backupUploadForm
/**
* @see \App\Http\Controllers\Api\DriveController::backupStatus
 * @see app/Http/Controllers/Api/DriveController.php:156
 * @route '/api/drive/backup-status'
 */
export const backupStatus = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: backupStatus.url(options),
    method: 'get',
})

backupStatus.definition = {
    methods: ["get","head"],
    url: '/api/drive/backup-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DriveController::backupStatus
 * @see app/Http/Controllers/Api/DriveController.php:156
 * @route '/api/drive/backup-status'
 */
backupStatus.url = (options?: RouteQueryOptions) => {
    return backupStatus.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::backupStatus
 * @see app/Http/Controllers/Api/DriveController.php:156
 * @route '/api/drive/backup-status'
 */
backupStatus.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: backupStatus.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DriveController::backupStatus
 * @see app/Http/Controllers/Api/DriveController.php:156
 * @route '/api/drive/backup-status'
 */
backupStatus.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: backupStatus.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::backupStatus
 * @see app/Http/Controllers/Api/DriveController.php:156
 * @route '/api/drive/backup-status'
 */
    const backupStatusForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: backupStatus.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::backupStatus
 * @see app/Http/Controllers/Api/DriveController.php:156
 * @route '/api/drive/backup-status'
 */
        backupStatusForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: backupStatus.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DriveController::backupStatus
 * @see app/Http/Controllers/Api/DriveController.php:156
 * @route '/api/drive/backup-status'
 */
        backupStatusForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: backupStatus.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    backupStatus.form = backupStatusForm
/**
* @see \App\Http\Controllers\Api\DriveController::download
 * @see app/Http/Controllers/Api/DriveController.php:169
 * @route '/api/drive/items/{item}/download'
 */
export const download = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/api/drive/items/{item}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DriveController::download
 * @see app/Http/Controllers/Api/DriveController.php:169
 * @route '/api/drive/items/{item}/download'
 */
download.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return download.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::download
 * @see app/Http/Controllers/Api/DriveController.php:169
 * @route '/api/drive/items/{item}/download'
 */
download.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DriveController::download
 * @see app/Http/Controllers/Api/DriveController.php:169
 * @route '/api/drive/items/{item}/download'
 */
download.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::download
 * @see app/Http/Controllers/Api/DriveController.php:169
 * @route '/api/drive/items/{item}/download'
 */
    const downloadForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::download
 * @see app/Http/Controllers/Api/DriveController.php:169
 * @route '/api/drive/items/{item}/download'
 */
        downloadForm.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DriveController::download
 * @see app/Http/Controllers/Api/DriveController.php:169
 * @route '/api/drive/items/{item}/download'
 */
        downloadForm.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
/**
* @see \App\Http\Controllers\Api\DriveController::toggleStar
 * @see app/Http/Controllers/Api/DriveController.php:180
 * @route '/api/drive/items/{item}/star'
 */
export const toggleStar = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStar.url(args, options),
    method: 'patch',
})

toggleStar.definition = {
    methods: ["patch"],
    url: '/api/drive/items/{item}/star',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\DriveController::toggleStar
 * @see app/Http/Controllers/Api/DriveController.php:180
 * @route '/api/drive/items/{item}/star'
 */
toggleStar.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return toggleStar.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::toggleStar
 * @see app/Http/Controllers/Api/DriveController.php:180
 * @route '/api/drive/items/{item}/star'
 */
toggleStar.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStar.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::toggleStar
 * @see app/Http/Controllers/Api/DriveController.php:180
 * @route '/api/drive/items/{item}/star'
 */
    const toggleStarForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStar.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::toggleStar
 * @see app/Http/Controllers/Api/DriveController.php:180
 * @route '/api/drive/items/{item}/star'
 */
        toggleStarForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStar.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleStar.form = toggleStarForm
/**
* @see \App\Http\Controllers\Api\DriveController::rename
 * @see app/Http/Controllers/Api/DriveController.php:189
 * @route '/api/drive/items/{item}/rename'
 */
export const rename = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: rename.url(args, options),
    method: 'patch',
})

rename.definition = {
    methods: ["patch"],
    url: '/api/drive/items/{item}/rename',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\DriveController::rename
 * @see app/Http/Controllers/Api/DriveController.php:189
 * @route '/api/drive/items/{item}/rename'
 */
rename.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return rename.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::rename
 * @see app/Http/Controllers/Api/DriveController.php:189
 * @route '/api/drive/items/{item}/rename'
 */
rename.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: rename.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::rename
 * @see app/Http/Controllers/Api/DriveController.php:189
 * @route '/api/drive/items/{item}/rename'
 */
    const renameForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rename.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::rename
 * @see app/Http/Controllers/Api/DriveController.php:189
 * @route '/api/drive/items/{item}/rename'
 */
        renameForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rename.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    rename.form = renameForm
/**
* @see \App\Http\Controllers\Api\DriveController::move
 * @see app/Http/Controllers/Api/DriveController.php:204
 * @route '/api/drive/items/{item}/move'
 */
export const move = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: move.url(args, options),
    method: 'patch',
})

move.definition = {
    methods: ["patch"],
    url: '/api/drive/items/{item}/move',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\DriveController::move
 * @see app/Http/Controllers/Api/DriveController.php:204
 * @route '/api/drive/items/{item}/move'
 */
move.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return move.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::move
 * @see app/Http/Controllers/Api/DriveController.php:204
 * @route '/api/drive/items/{item}/move'
 */
move.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: move.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::move
 * @see app/Http/Controllers/Api/DriveController.php:204
 * @route '/api/drive/items/{item}/move'
 */
    const moveForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: move.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::move
 * @see app/Http/Controllers/Api/DriveController.php:204
 * @route '/api/drive/items/{item}/move'
 */
        moveForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: move.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    move.form = moveForm
/**
* @see \App\Http\Controllers\Api\DriveController::restore
 * @see app/Http/Controllers/Api/DriveController.php:215
 * @route '/api/drive/items/{item}/restore'
 */
export const restore = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

restore.definition = {
    methods: ["patch"],
    url: '/api/drive/items/{item}/restore',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\DriveController::restore
 * @see app/Http/Controllers/Api/DriveController.php:215
 * @route '/api/drive/items/{item}/restore'
 */
restore.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return restore.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::restore
 * @see app/Http/Controllers/Api/DriveController.php:215
 * @route '/api/drive/items/{item}/restore'
 */
restore.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::restore
 * @see app/Http/Controllers/Api/DriveController.php:215
 * @route '/api/drive/items/{item}/restore'
 */
    const restoreForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::restore
 * @see app/Http/Controllers/Api/DriveController.php:215
 * @route '/api/drive/items/{item}/restore'
 */
        restoreForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Api\DriveController::share
 * @see app/Http/Controllers/Api/DriveController.php:241
 * @route '/api/drive/items/{item}/share'
 */
export const share = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: share.url(args, options),
    method: 'post',
})

share.definition = {
    methods: ["post"],
    url: '/api/drive/items/{item}/share',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DriveController::share
 * @see app/Http/Controllers/Api/DriveController.php:241
 * @route '/api/drive/items/{item}/share'
 */
share.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return share.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::share
 * @see app/Http/Controllers/Api/DriveController.php:241
 * @route '/api/drive/items/{item}/share'
 */
share.post = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: share.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::share
 * @see app/Http/Controllers/Api/DriveController.php:241
 * @route '/api/drive/items/{item}/share'
 */
    const shareForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: share.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::share
 * @see app/Http/Controllers/Api/DriveController.php:241
 * @route '/api/drive/items/{item}/share'
 */
        shareForm.post = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: share.url(args, options),
            method: 'post',
        })
    
    share.form = shareForm
/**
* @see \App\Http\Controllers\Api\DriveController::unshare
 * @see app/Http/Controllers/Api/DriveController.php:262
 * @route '/api/drive/items/{item}/share'
 */
export const unshare = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unshare.url(args, options),
    method: 'delete',
})

unshare.definition = {
    methods: ["delete"],
    url: '/api/drive/items/{item}/share',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\DriveController::unshare
 * @see app/Http/Controllers/Api/DriveController.php:262
 * @route '/api/drive/items/{item}/share'
 */
unshare.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return unshare.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::unshare
 * @see app/Http/Controllers/Api/DriveController.php:262
 * @route '/api/drive/items/{item}/share'
 */
unshare.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unshare.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::unshare
 * @see app/Http/Controllers/Api/DriveController.php:262
 * @route '/api/drive/items/{item}/share'
 */
    const unshareForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unshare.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::unshare
 * @see app/Http/Controllers/Api/DriveController.php:262
 * @route '/api/drive/items/{item}/share'
 */
        unshareForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unshare.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unshare.form = unshareForm
/**
* @see \App\Http\Controllers\Api\DriveController::destroy
 * @see app/Http/Controllers/Api/DriveController.php:271
 * @route '/api/drive/items/{item}'
 */
export const destroy = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/drive/items/{item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\DriveController::destroy
 * @see app/Http/Controllers/Api/DriveController.php:271
 * @route '/api/drive/items/{item}'
 */
destroy.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return destroy.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DriveController::destroy
 * @see app/Http/Controllers/Api/DriveController.php:271
 * @route '/api/drive/items/{item}'
 */
destroy.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\DriveController::destroy
 * @see app/Http/Controllers/Api/DriveController.php:271
 * @route '/api/drive/items/{item}'
 */
    const destroyForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DriveController::destroy
 * @see app/Http/Controllers/Api/DriveController.php:271
 * @route '/api/drive/items/{item}'
 */
        destroyForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DriveController = { index, storage, allFolders, createFolder, upload, backupUpload, backupStatus, download, toggleStar, rename, move, restore, share, unshare, destroy }

export default DriveController