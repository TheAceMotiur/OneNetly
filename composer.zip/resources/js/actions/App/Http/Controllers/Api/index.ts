import AuthController from './AuthController'
import DriveController from './DriveController'
import SubscriptionController from './SubscriptionController'
const Api = {
    AuthController: Object.assign(AuthController, AuthController),
DriveController: Object.assign(DriveController, DriveController),
SubscriptionController: Object.assign(SubscriptionController, SubscriptionController),
}

export default Api