import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DriveController::publicShow
 * @see app/Http/Controllers/DriveController.php:582
 * @route '/drive/s/{token}'
 */
export const publicShow = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: publicShow.url(args, options),
    method: 'get',
})

publicShow.definition = {
    methods: ["get","head"],
    url: '/drive/s/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DriveController::publicShow
 * @see app/Http/Controllers/DriveController.php:582
 * @route '/drive/s/{token}'
 */
publicShow.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return publicShow.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::publicShow
 * @see app/Http/Controllers/DriveController.php:582
 * @route '/drive/s/{token}'
 */
publicShow.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: publicShow.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DriveController::publicShow
 * @see app/Http/Controllers/DriveController.php:582
 * @route '/drive/s/{token}'
 */
publicShow.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: publicShow.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DriveController::publicShow
 * @see app/Http/Controllers/DriveController.php:582
 * @route '/drive/s/{token}'
 */
    const publicShowForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: publicShow.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DriveController::publicShow
 * @see app/Http/Controllers/DriveController.php:582
 * @route '/drive/s/{token}'
 */
        publicShowForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: publicShow.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DriveController::publicShow
 * @see app/Http/Controllers/DriveController.php:582
 * @route '/drive/s/{token}'
 */
        publicShowForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: publicShow.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    publicShow.form = publicShowForm
/**
* @see \App\Http\Controllers\DriveController::publicDownload
 * @see app/Http/Controllers/DriveController.php:603
 * @route '/drive/public/{token}'
 */
export const publicDownload = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: publicDownload.url(args, options),
    method: 'get',
})

publicDownload.definition = {
    methods: ["get","head"],
    url: '/drive/public/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DriveController::publicDownload
 * @see app/Http/Controllers/DriveController.php:603
 * @route '/drive/public/{token}'
 */
publicDownload.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return publicDownload.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::publicDownload
 * @see app/Http/Controllers/DriveController.php:603
 * @route '/drive/public/{token}'
 */
publicDownload.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: publicDownload.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DriveController::publicDownload
 * @see app/Http/Controllers/DriveController.php:603
 * @route '/drive/public/{token}'
 */
publicDownload.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: publicDownload.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DriveController::publicDownload
 * @see app/Http/Controllers/DriveController.php:603
 * @route '/drive/public/{token}'
 */
    const publicDownloadForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: publicDownload.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DriveController::publicDownload
 * @see app/Http/Controllers/DriveController.php:603
 * @route '/drive/public/{token}'
 */
        publicDownloadForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: publicDownload.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DriveController::publicDownload
 * @see app/Http/Controllers/DriveController.php:603
 * @route '/drive/public/{token}'
 */
        publicDownloadForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: publicDownload.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    publicDownload.form = publicDownloadForm
/**
* @see \App\Http\Controllers\DriveController::publicPreview
 * @see app/Http/Controllers/DriveController.php:615
 * @route '/drive/public/{token}/preview'
 */
export const publicPreview = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: publicPreview.url(args, options),
    method: 'get',
})

publicPreview.definition = {
    methods: ["get","head"],
    url: '/drive/public/{token}/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DriveController::publicPreview
 * @see app/Http/Controllers/DriveController.php:615
 * @route '/drive/public/{token}/preview'
 */
publicPreview.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return publicPreview.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::publicPreview
 * @see app/Http/Controllers/DriveController.php:615
 * @route '/drive/public/{token}/preview'
 */
publicPreview.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: publicPreview.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DriveController::publicPreview
 * @see app/Http/Controllers/DriveController.php:615
 * @route '/drive/public/{token}/preview'
 */
publicPreview.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: publicPreview.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DriveController::publicPreview
 * @see app/Http/Controllers/DriveController.php:615
 * @route '/drive/public/{token}/preview'
 */
    const publicPreviewForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: publicPreview.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DriveController::publicPreview
 * @see app/Http/Controllers/DriveController.php:615
 * @route '/drive/public/{token}/preview'
 */
        publicPreviewForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: publicPreview.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DriveController::publicPreview
 * @see app/Http/Controllers/DriveController.php:615
 * @route '/drive/public/{token}/preview'
 */
        publicPreviewForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: publicPreview.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    publicPreview.form = publicPreviewForm
/**
* @see \App\Http\Controllers\DriveController::index
 * @see app/Http/Controllers/DriveController.php:25
 * @route '/dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DriveController::index
 * @see app/Http/Controllers/DriveController.php:25
 * @route '/dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::index
 * @see app/Http/Controllers/DriveController.php:25
 * @route '/dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DriveController::index
 * @see app/Http/Controllers/DriveController.php:25
 * @route '/dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DriveController::index
 * @see app/Http/Controllers/DriveController.php:25
 * @route '/dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DriveController::index
 * @see app/Http/Controllers/DriveController.php:25
 * @route '/dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DriveController::index
 * @see app/Http/Controllers/DriveController.php:25
 * @route '/dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DriveController::createFolder
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
export const createFolder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createFolder.url(options),
    method: 'post',
})

createFolder.definition = {
    methods: ["post"],
    url: '/drive/folders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DriveController::createFolder
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
createFolder.url = (options?: RouteQueryOptions) => {
    return createFolder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::createFolder
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
createFolder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createFolder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DriveController::createFolder
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
    const createFolderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: createFolder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::createFolder
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
        createFolderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: createFolder.url(options),
            method: 'post',
        })
    
    createFolder.form = createFolderForm
/**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
export const upload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

upload.definition = {
    methods: ["post"],
    url: '/drive/upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
upload.url = (options?: RouteQueryOptions) => {
    return upload.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
upload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
    const uploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upload.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
        uploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upload.url(options),
            method: 'post',
        })
    
    upload.form = uploadForm
/**
* @see \App\Http\Controllers\DriveController::bulkAction
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
export const bulkAction = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAction.url(options),
    method: 'post',
})

bulkAction.definition = {
    methods: ["post"],
    url: '/drive/bulk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DriveController::bulkAction
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
bulkAction.url = (options?: RouteQueryOptions) => {
    return bulkAction.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::bulkAction
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
bulkAction.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAction.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DriveController::bulkAction
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
    const bulkActionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkAction.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::bulkAction
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
        bulkActionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkAction.url(options),
            method: 'post',
        })
    
    bulkAction.form = bulkActionForm
/**
* @see \App\Http\Controllers\DriveController::rename
 * @see app/Http/Controllers/DriveController.php:263
 * @route '/drive/items/{item}/rename'
 */
export const rename = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: rename.url(args, options),
    method: 'patch',
})

rename.definition = {
    methods: ["patch"],
    url: '/drive/items/{item}/rename',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DriveController::rename
 * @see app/Http/Controllers/DriveController.php:263
 * @route '/drive/items/{item}/rename'
 */
rename.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return rename.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::rename
 * @see app/Http/Controllers/DriveController.php:263
 * @route '/drive/items/{item}/rename'
 */
rename.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: rename.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DriveController::rename
 * @see app/Http/Controllers/DriveController.php:263
 * @route '/drive/items/{item}/rename'
 */
    const renameForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rename.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::rename
 * @see app/Http/Controllers/DriveController.php:263
 * @route '/drive/items/{item}/rename'
 */
        renameForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rename.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    rename.form = renameForm
/**
* @see \App\Http\Controllers\DriveController::move
 * @see app/Http/Controllers/DriveController.php:336
 * @route '/drive/items/{item}/move'
 */
export const move = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: move.url(args, options),
    method: 'patch',
})

move.definition = {
    methods: ["patch"],
    url: '/drive/items/{item}/move',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DriveController::move
 * @see app/Http/Controllers/DriveController.php:336
 * @route '/drive/items/{item}/move'
 */
move.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return move.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::move
 * @see app/Http/Controllers/DriveController.php:336
 * @route '/drive/items/{item}/move'
 */
move.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: move.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DriveController::move
 * @see app/Http/Controllers/DriveController.php:336
 * @route '/drive/items/{item}/move'
 */
    const moveForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: move.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::move
 * @see app/Http/Controllers/DriveController.php:336
 * @route '/drive/items/{item}/move'
 */
        moveForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: move.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    move.form = moveForm
/**
* @see \App\Http\Controllers\DriveController::toggleStar
 * @see app/Http/Controllers/DriveController.php:494
 * @route '/drive/items/{item}/star'
 */
export const toggleStar = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStar.url(args, options),
    method: 'patch',
})

toggleStar.definition = {
    methods: ["patch"],
    url: '/drive/items/{item}/star',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DriveController::toggleStar
 * @see app/Http/Controllers/DriveController.php:494
 * @route '/drive/items/{item}/star'
 */
toggleStar.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return toggleStar.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::toggleStar
 * @see app/Http/Controllers/DriveController.php:494
 * @route '/drive/items/{item}/star'
 */
toggleStar.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStar.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DriveController::toggleStar
 * @see app/Http/Controllers/DriveController.php:494
 * @route '/drive/items/{item}/star'
 */
    const toggleStarForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStar.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::toggleStar
 * @see app/Http/Controllers/DriveController.php:494
 * @route '/drive/items/{item}/star'
 */
        toggleStarForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStar.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleStar.form = toggleStarForm
/**
* @see \App\Http\Controllers\DriveController::restore
 * @see app/Http/Controllers/DriveController.php:540
 * @route '/drive/items/{item}/restore'
 */
export const restore = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

restore.definition = {
    methods: ["patch"],
    url: '/drive/items/{item}/restore',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DriveController::restore
 * @see app/Http/Controllers/DriveController.php:540
 * @route '/drive/items/{item}/restore'
 */
restore.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return restore.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::restore
 * @see app/Http/Controllers/DriveController.php:540
 * @route '/drive/items/{item}/restore'
 */
restore.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DriveController::restore
 * @see app/Http/Controllers/DriveController.php:540
 * @route '/drive/items/{item}/restore'
 */
    const restoreForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::restore
 * @see app/Http/Controllers/DriveController.php:540
 * @route '/drive/items/{item}/restore'
 */
        restoreForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\DriveController::duplicate
 * @see app/Http/Controllers/DriveController.php:289
 * @route '/drive/items/{item}/duplicate'
 */
export const duplicate = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: duplicate.url(args, options),
    method: 'post',
})

duplicate.definition = {
    methods: ["post"],
    url: '/drive/items/{item}/duplicate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DriveController::duplicate
 * @see app/Http/Controllers/DriveController.php:289
 * @route '/drive/items/{item}/duplicate'
 */
duplicate.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return duplicate.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::duplicate
 * @see app/Http/Controllers/DriveController.php:289
 * @route '/drive/items/{item}/duplicate'
 */
duplicate.post = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: duplicate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DriveController::duplicate
 * @see app/Http/Controllers/DriveController.php:289
 * @route '/drive/items/{item}/duplicate'
 */
    const duplicateForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: duplicate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::duplicate
 * @see app/Http/Controllers/DriveController.php:289
 * @route '/drive/items/{item}/duplicate'
 */
        duplicateForm.post = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: duplicate.url(args, options),
            method: 'post',
        })
    
    duplicate.form = duplicateForm
/**
* @see \App\Http\Controllers\DriveController::share
 * @see app/Http/Controllers/DriveController.php:455
 * @route '/drive/items/{item}/share'
 */
export const share = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: share.url(args, options),
    method: 'post',
})

share.definition = {
    methods: ["post"],
    url: '/drive/items/{item}/share',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DriveController::share
 * @see app/Http/Controllers/DriveController.php:455
 * @route '/drive/items/{item}/share'
 */
share.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return share.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::share
 * @see app/Http/Controllers/DriveController.php:455
 * @route '/drive/items/{item}/share'
 */
share.post = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: share.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DriveController::share
 * @see app/Http/Controllers/DriveController.php:455
 * @route '/drive/items/{item}/share'
 */
    const shareForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: share.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::share
 * @see app/Http/Controllers/DriveController.php:455
 * @route '/drive/items/{item}/share'
 */
        shareForm.post = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: share.url(args, options),
            method: 'post',
        })
    
    share.form = shareForm
/**
* @see \App\Http\Controllers\DriveController::unshare
 * @see app/Http/Controllers/DriveController.php:477
 * @route '/drive/items/{item}/unshare'
 */
export const unshare = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unshare.url(args, options),
    method: 'delete',
})

unshare.definition = {
    methods: ["delete"],
    url: '/drive/items/{item}/unshare',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DriveController::unshare
 * @see app/Http/Controllers/DriveController.php:477
 * @route '/drive/items/{item}/unshare'
 */
unshare.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return unshare.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::unshare
 * @see app/Http/Controllers/DriveController.php:477
 * @route '/drive/items/{item}/unshare'
 */
unshare.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unshare.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DriveController::unshare
 * @see app/Http/Controllers/DriveController.php:477
 * @route '/drive/items/{item}/unshare'
 */
    const unshareForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unshare.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::unshare
 * @see app/Http/Controllers/DriveController.php:477
 * @route '/drive/items/{item}/unshare'
 */
        unshareForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unshare.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unshare.form = unshareForm
/**
* @see \App\Http\Controllers\DriveController::destroy
 * @see app/Http/Controllers/DriveController.php:510
 * @route '/drive/items/{item}'
 */
export const destroy = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/drive/items/{item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DriveController::destroy
 * @see app/Http/Controllers/DriveController.php:510
 * @route '/drive/items/{item}'
 */
destroy.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return destroy.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::destroy
 * @see app/Http/Controllers/DriveController.php:510
 * @route '/drive/items/{item}'
 */
destroy.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DriveController::destroy
 * @see app/Http/Controllers/DriveController.php:510
 * @route '/drive/items/{item}'
 */
    const destroyForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::destroy
 * @see app/Http/Controllers/DriveController.php:510
 * @route '/drive/items/{item}'
 */
        destroyForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\DriveController::preview
 * @see app/Http/Controllers/DriveController.php:554
 * @route '/drive/items/{item}/preview'
 */
export const preview = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/drive/items/{item}/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DriveController::preview
 * @see app/Http/Controllers/DriveController.php:554
 * @route '/drive/items/{item}/preview'
 */
preview.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return preview.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::preview
 * @see app/Http/Controllers/DriveController.php:554
 * @route '/drive/items/{item}/preview'
 */
preview.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DriveController::preview
 * @see app/Http/Controllers/DriveController.php:554
 * @route '/drive/items/{item}/preview'
 */
preview.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DriveController::preview
 * @see app/Http/Controllers/DriveController.php:554
 * @route '/drive/items/{item}/preview'
 */
    const previewForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preview.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DriveController::preview
 * @see app/Http/Controllers/DriveController.php:554
 * @route '/drive/items/{item}/preview'
 */
        previewForm.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DriveController::preview
 * @see app/Http/Controllers/DriveController.php:554
 * @route '/drive/items/{item}/preview'
 */
        previewForm.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preview.form = previewForm
/**
* @see \App\Http\Controllers\DriveController::download
 * @see app/Http/Controllers/DriveController.php:568
 * @route '/drive/items/{item}/download'
 */
export const download = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/drive/items/{item}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DriveController::download
 * @see app/Http/Controllers/DriveController.php:568
 * @route '/drive/items/{item}/download'
 */
download.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return download.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::download
 * @see app/Http/Controllers/DriveController.php:568
 * @route '/drive/items/{item}/download'
 */
download.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DriveController::download
 * @see app/Http/Controllers/DriveController.php:568
 * @route '/drive/items/{item}/download'
 */
download.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DriveController::download
 * @see app/Http/Controllers/DriveController.php:568
 * @route '/drive/items/{item}/download'
 */
    const downloadForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DriveController::download
 * @see app/Http/Controllers/DriveController.php:568
 * @route '/drive/items/{item}/download'
 */
        downloadForm.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DriveController::download
 * @see app/Http/Controllers/DriveController.php:568
 * @route '/drive/items/{item}/download'
 */
        downloadForm.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const DriveController = { publicShow, publicDownload, publicPreview, index, createFolder, upload, bulkAction, rename, move, toggleStar, restore, duplicate, share, unshare, destroy, preview, download }

export default DriveController