import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PayPalIpnController::handle
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
export const handle = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: handle.url(options),
    method: 'post',
})

handle.definition = {
    methods: ["post"],
    url: '/webhooks/paypal/ipn',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PayPalIpnController::handle
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
handle.url = (options?: RouteQueryOptions) => {
    return handle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PayPalIpnController::handle
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
handle.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: handle.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PayPalIpnController::handle
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
    const handleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: handle.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PayPalIpnController::handle
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
        handleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: handle.url(options),
            method: 'post',
        })
    
    handle.form = handleForm
const PayPalIpnController = { handle }

export default PayPalIpnController