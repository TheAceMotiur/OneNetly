import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pricing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SubscriptionController::createOrder
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
export const createOrder = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createOrder.url(args, options),
    method: 'post',
})

createOrder.definition = {
    methods: ["post"],
    url: '/subscriptions/{plan}/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::createOrder
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
createOrder.url = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { plan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { plan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return createOrder.definition.url
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::createOrder
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
createOrder.post = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createOrder.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::createOrder
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
    const createOrderForm = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: createOrder.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::createOrder
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
        createOrderForm.post = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: createOrder.url(args, options),
            method: 'post',
        })
    
    createOrder.form = createOrderForm
/**
* @see \App\Http\Controllers\SubscriptionController::captureOrder
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
export const captureOrder = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: captureOrder.url(args, options),
    method: 'post',
})

captureOrder.definition = {
    methods: ["post"],
    url: '/subscriptions/orders/{orderId}/capture',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::captureOrder
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
captureOrder.url = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    orderId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        orderId: args.orderId,
                }

    return captureOrder.definition.url
            .replace('{orderId}', parsedArgs.orderId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::captureOrder
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
captureOrder.post = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: captureOrder.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::captureOrder
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
    const captureOrderForm = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: captureOrder.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::captureOrder
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
        captureOrderForm.post = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: captureOrder.url(args, options),
            method: 'post',
        })
    
    captureOrder.form = captureOrderForm
/**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
export const standardCheckout = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: standardCheckout.url(args, options),
    method: 'get',
})

standardCheckout.definition = {
    methods: ["get","head"],
    url: '/subscriptions/{plan}/paypal-standard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
standardCheckout.url = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { plan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { plan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return standardCheckout.definition.url
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
standardCheckout.get = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: standardCheckout.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
standardCheckout.head = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: standardCheckout.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
    const standardCheckoutForm = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: standardCheckout.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
        standardCheckoutForm.get = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: standardCheckout.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
        standardCheckoutForm.head = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: standardCheckout.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    standardCheckout.form = standardCheckoutForm
/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/subscriptions/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
cancel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
    const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
        cancelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(options),
            method: 'post',
        })
    
    cancel.form = cancelForm
const SubscriptionController = { index, createOrder, captureOrder, standardCheckout, cancel }

export default SubscriptionController