import Api from './Api'
import SubscriptionController from './SubscriptionController'
import DriveController from './DriveController'
import PayPalIpnController from './PayPalIpnController'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    Api: Object.assign(Api, Api),
SubscriptionController: Object.assign(SubscriptionController, SubscriptionController),
DriveController: Object.assign(DriveController, DriveController),
PayPalIpnController: Object.assign(PayPalIpnController, PayPalIpnController),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers