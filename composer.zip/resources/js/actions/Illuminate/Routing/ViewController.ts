import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
const ViewController2f553c97c7d43e339fc6cd117494aacf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController2f553c97c7d43e339fc6cd117494aacf.url(options),
    method: 'get',
})

ViewController2f553c97c7d43e339fc6cd117494aacf.definition = {
    methods: ["get","head"],
    url: '/subscriptions/mobile-return',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
ViewController2f553c97c7d43e339fc6cd117494aacf.url = (options?: RouteQueryOptions) => {
    return ViewController2f553c97c7d43e339fc6cd117494aacf.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
ViewController2f553c97c7d43e339fc6cd117494aacf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController2f553c97c7d43e339fc6cd117494aacf.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
ViewController2f553c97c7d43e339fc6cd117494aacf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController2f553c97c7d43e339fc6cd117494aacf.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
    const ViewController2f553c97c7d43e339fc6cd117494aacfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController2f553c97c7d43e339fc6cd117494aacf.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
        ViewController2f553c97c7d43e339fc6cd117494aacfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController2f553c97c7d43e339fc6cd117494aacf.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
        ViewController2f553c97c7d43e339fc6cd117494aacfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController2f553c97c7d43e339fc6cd117494aacf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController2f553c97c7d43e339fc6cd117494aacf.form = ViewController2f553c97c7d43e339fc6cd117494aacfForm
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
const ViewController49e6a8659b788ac776656a9b97b0fae1 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController49e6a8659b788ac776656a9b97b0fae1.url(options),
    method: 'get',
})

ViewController49e6a8659b788ac776656a9b97b0fae1.definition = {
    methods: ["get","head"],
    url: '/subscriptions/mobile-cancel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
ViewController49e6a8659b788ac776656a9b97b0fae1.url = (options?: RouteQueryOptions) => {
    return ViewController49e6a8659b788ac776656a9b97b0fae1.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
ViewController49e6a8659b788ac776656a9b97b0fae1.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController49e6a8659b788ac776656a9b97b0fae1.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
ViewController49e6a8659b788ac776656a9b97b0fae1.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController49e6a8659b788ac776656a9b97b0fae1.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
    const ViewController49e6a8659b788ac776656a9b97b0fae1Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController49e6a8659b788ac776656a9b97b0fae1.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
        ViewController49e6a8659b788ac776656a9b97b0fae1Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController49e6a8659b788ac776656a9b97b0fae1.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
        ViewController49e6a8659b788ac776656a9b97b0fae1Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController49e6a8659b788ac776656a9b97b0fae1.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController49e6a8659b788ac776656a9b97b0fae1.form = ViewController49e6a8659b788ac776656a9b97b0fae1Form

/**
* Multiple routes resolve to \Illuminate\Routing\ViewController::ViewController, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `ViewController['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
const ViewController = {
    '/subscriptions/mobile-return': ViewController2f553c97c7d43e339fc6cd117494aacf,
    '/subscriptions/mobile-cancel': ViewController49e6a8659b788ac776656a9b97b0fae1,
}

export default ViewController