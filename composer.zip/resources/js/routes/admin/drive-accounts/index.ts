import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/drive-accounts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::index
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:24
 * @route '/admin/drive-accounts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::store
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:74
 * @route '/admin/drive-accounts'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAll
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
export const syncAll = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncAll.url(options),
    method: 'post',
})

syncAll.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts/sync-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAll
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
syncAll.url = (options?: RouteQueryOptions) => {
    return syncAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAll
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
syncAll.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncAll.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAll
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
    const syncAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: syncAll.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::syncAll
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:173
 * @route '/admin/drive-accounts/sync-all'
 */
        syncAllForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: syncAll.url(options),
            method: 'post',
        })
    
    syncAll.form = syncAllForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
export const testCredentials = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testCredentials.url(options),
    method: 'post',
})

testCredentials.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts/test-credentials',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
testCredentials.url = (options?: RouteQueryOptions) => {
    return testCredentials.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
testCredentials.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testCredentials.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
    const testCredentialsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: testCredentials.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::testCredentials
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:228
 * @route '/admin/drive-accounts/test-credentials'
 */
        testCredentialsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: testCredentials.url(options),
            method: 'post',
        })
    
    testCredentials.form = testCredentialsForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
export const test = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

test.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts/{driveAccount}/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
test.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return test.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
test.post = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
    const testForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: test.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::test
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:218
 * @route '/admin/drive-accounts/{driveAccount}/test'
 */
        testForm.post = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: test.url(args, options),
            method: 'post',
        })
    
    test.form = testForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::sync
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
export const sync = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/admin/drive-accounts/{driveAccount}/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::sync
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
sync.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return sync.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::sync
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
sync.post = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::sync
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
    const syncForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sync.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::sync
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:159
 * @route '/admin/drive-accounts/{driveAccount}/sync'
 */
        syncForm.post = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sync.url(args, options),
            method: 'post',
        })
    
    sync.form = syncForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::priority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
export const priority = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: priority.url(args, options),
    method: 'patch',
})

priority.definition = {
    methods: ["patch"],
    url: '/admin/drive-accounts/{driveAccount}/priority',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::priority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
priority.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return priority.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::priority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
priority.patch = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: priority.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::priority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
    const priorityForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: priority.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::priority
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:145
 * @route '/admin/drive-accounts/{driveAccount}/priority'
 */
        priorityForm.patch = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: priority.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    priority.form = priorityForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
export const update = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/drive-accounts/{driveAccount}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
update.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return update.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
update.put = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
    const updateForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::update
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:109
 * @route '/admin/drive-accounts/{driveAccount}'
 */
        updateForm.put = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggle
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
export const toggle = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggle.url(args, options),
    method: 'patch',
})

toggle.definition = {
    methods: ["patch"],
    url: '/admin/drive-accounts/{driveAccount}/toggle',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggle
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
toggle.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return toggle.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggle
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
toggle.patch = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggle.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggle
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
    const toggleForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggle.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::toggle
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:194
 * @route '/admin/drive-accounts/{driveAccount}/toggle'
 */
        toggleForm.patch = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggle.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggle.form = toggleForm
/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
export const destroy = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/drive-accounts/{driveAccount}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
destroy.url = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driveAccount: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driveAccount: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driveAccount: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driveAccount: typeof args.driveAccount === 'object'
                ? args.driveAccount.id
                : args.driveAccount,
                }

    return destroy.definition.url
            .replace('{driveAccount}', parsedArgs.driveAccount.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
destroy.delete = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
    const destroyForm = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDriveAccountController::destroy
 * @see app/Http/Controllers/Admin/AdminDriveAccountController.php:208
 * @route '/admin/drive-accounts/{driveAccount}'
 */
        destroyForm.delete = (args: { driveAccount: number | { id: number } } | [driveAccount: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const driveAccounts = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
syncAll: Object.assign(syncAll, syncAll),
testCredentials: Object.assign(testCredentials, testCredentials),
test: Object.assign(test, test),
sync: Object.assign(sync, sync),
priority: Object.assign(priority, priority),
update: Object.assign(update, update),
toggle: Object.assign(toggle, toggle),
destroy: Object.assign(destroy, destroy),
}

export default driveAccounts