import monetization from './monetization'
const settings = {
    monetization: Object.assign(monetization, monetization),
}

export default settings