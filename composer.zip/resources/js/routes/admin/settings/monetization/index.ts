import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/settings/monetization',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::edit
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:20
 * @route '/admin/settings/monetization'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
export const paypal = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: paypal.url(options),
    method: 'put',
})

paypal.definition = {
    methods: ["put"],
    url: '/admin/settings/monetization/paypal',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
paypal.url = (options?: RouteQueryOptions) => {
    return paypal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
paypal.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: paypal.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
    const paypalForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: paypal.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypal
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:42
 * @route '/admin/settings/monetization/paypal'
 */
        paypalForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: paypal.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    paypal.form = paypalForm
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::adsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
export const adsense = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: adsense.url(options),
    method: 'put',
})

adsense.definition = {
    methods: ["put"],
    url: '/admin/settings/monetization/adsense',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::adsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
adsense.url = (options?: RouteQueryOptions) => {
    return adsense.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::adsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
adsense.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: adsense.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::adsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
    const adsenseForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adsense.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::adsense
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:65
 * @route '/admin/settings/monetization/adsense'
 */
        adsenseForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adsense.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    adsense.form = adsenseForm
/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypalTest
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
export const paypalTest = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paypalTest.url(options),
    method: 'post',
})

paypalTest.definition = {
    methods: ["post"],
    url: '/admin/settings/monetization/paypal/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypalTest
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
paypalTest.url = (options?: RouteQueryOptions) => {
    return paypalTest.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypalTest
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
paypalTest.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paypalTest.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypalTest
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
    const paypalTestForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: paypalTest.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\MonetizationSettingsController::paypalTest
 * @see app/Http/Controllers/Admin/MonetizationSettingsController.php:83
 * @route '/admin/settings/monetization/paypal/test'
 */
        paypalTestForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: paypalTest.url(options),
            method: 'post',
        })
    
    paypalTest.form = paypalTestForm
const monetization = {
    edit: Object.assign(edit, edit),
paypal: Object.assign(paypal, paypal),
adsense: Object.assign(adsense, adsense),
paypalTest: Object.assign(paypalTest, paypalTest),
}

export default monetization