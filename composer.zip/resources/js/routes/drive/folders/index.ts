import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\DriveController::store
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/drive/folders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DriveController::store
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::store
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DriveController::store
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::store
 * @see app/Http/Controllers/DriveController.php:140
 * @route '/drive/folders'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const folders = {
    store: Object.assign(store, store),
}

export default folders