import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import publicMethod from './public'
import folders from './folders'
import items from './items'
/**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
export const upload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

upload.definition = {
    methods: ["post"],
    url: '/drive/upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
upload.url = (options?: RouteQueryOptions) => {
    return upload.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
upload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
    const uploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upload.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::upload
 * @see app/Http/Controllers/DriveController.php:174
 * @route '/drive/upload'
 */
        uploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upload.url(options),
            method: 'post',
        })
    
    upload.form = uploadForm
/**
* @see \App\Http\Controllers\DriveController::bulk
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
export const bulk = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulk.url(options),
    method: 'post',
})

bulk.definition = {
    methods: ["post"],
    url: '/drive/bulk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DriveController::bulk
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
bulk.url = (options?: RouteQueryOptions) => {
    return bulk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriveController::bulk
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
bulk.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulk.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DriveController::bulk
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
    const bulkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulk.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriveController::bulk
 * @see app/Http/Controllers/DriveController.php:388
 * @route '/drive/bulk'
 */
        bulkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulk.url(options),
            method: 'post',
        })
    
    bulk.form = bulkForm
const drive = {
    public: Object.assign(publicMethod, publicMethod),
folders: Object.assign(folders, folders),
upload: Object.assign(upload, upload),
bulk: Object.assign(bulk, bulk),
items: Object.assign(items, items),
}

export default drive