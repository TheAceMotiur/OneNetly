import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import orders from './orders'
/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pricing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:23
 * @route '/pricing'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
export const mobileReturn = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mobileReturn.url(options),
    method: 'get',
})

mobileReturn.definition = {
    methods: ["get","head"],
    url: '/subscriptions/mobile-return',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
mobileReturn.url = (options?: RouteQueryOptions) => {
    return mobileReturn.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
mobileReturn.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mobileReturn.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
mobileReturn.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: mobileReturn.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
    const mobileReturnForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: mobileReturn.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
        mobileReturnForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mobileReturn.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-return'
 */
        mobileReturnForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mobileReturn.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    mobileReturn.form = mobileReturnForm
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
export const mobileCancel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mobileCancel.url(options),
    method: 'get',
})

mobileCancel.definition = {
    methods: ["get","head"],
    url: '/subscriptions/mobile-cancel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
mobileCancel.url = (options?: RouteQueryOptions) => {
    return mobileCancel.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
mobileCancel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mobileCancel.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
mobileCancel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: mobileCancel.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
    const mobileCancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: mobileCancel.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
        mobileCancelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mobileCancel.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/subscriptions/mobile-cancel'
 */
        mobileCancelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mobileCancel.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    mobileCancel.form = mobileCancelForm
/**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
export const standardCheckout = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: standardCheckout.url(args, options),
    method: 'get',
})

standardCheckout.definition = {
    methods: ["get","head"],
    url: '/subscriptions/{plan}/paypal-standard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
standardCheckout.url = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { plan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { plan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return standardCheckout.definition.url
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
standardCheckout.get = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: standardCheckout.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
standardCheckout.head = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: standardCheckout.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
    const standardCheckoutForm = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: standardCheckout.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
        standardCheckoutForm.get = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: standardCheckout.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::standardCheckout
 * @see app/Http/Controllers/SubscriptionController.php:45
 * @route '/subscriptions/{plan}/paypal-standard'
 */
        standardCheckoutForm.head = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: standardCheckout.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    standardCheckout.form = standardCheckoutForm
/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/subscriptions/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
cancel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
    const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:125
 * @route '/subscriptions/cancel'
 */
        cancelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(options),
            method: 'post',
        })
    
    cancel.form = cancelForm
const subscriptions = {
    index: Object.assign(index, index),
mobileReturn: Object.assign(mobileReturn, mobileReturn),
mobileCancel: Object.assign(mobileCancel, mobileCancel),
orders: Object.assign(orders, orders),
standardCheckout: Object.assign(standardCheckout, standardCheckout),
cancel: Object.assign(cancel, cancel),
}

export default subscriptions