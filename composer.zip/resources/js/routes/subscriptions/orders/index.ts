import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\SubscriptionController::create
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
export const create = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(args, options),
    method: 'post',
})

create.definition = {
    methods: ["post"],
    url: '/subscriptions/{plan}/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::create
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
create.url = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { plan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { plan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return create.definition.url
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::create
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
create.post = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::create
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
    const createForm = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: create.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::create
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscriptions/{plan}/orders'
 */
        createForm.post = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: create.url(args, options),
            method: 'post',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\SubscriptionController::capture
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
export const capture = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: capture.url(args, options),
    method: 'post',
})

capture.definition = {
    methods: ["post"],
    url: '/subscriptions/orders/{orderId}/capture',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::capture
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
capture.url = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    orderId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        orderId: args.orderId,
                }

    return capture.definition.url
            .replace('{orderId}', parsedArgs.orderId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::capture
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
capture.post = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: capture.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::capture
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
    const captureForm = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: capture.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::capture
 * @see app/Http/Controllers/SubscriptionController.php:84
 * @route '/subscriptions/orders/{orderId}/capture'
 */
        captureForm.post = (args: { orderId: string | number } | [orderId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: capture.url(args, options),
            method: 'post',
        })
    
    capture.form = captureForm
const orders = {
    create: Object.assign(create, create),
capture: Object.assign(capture, capture),
}

export default orders