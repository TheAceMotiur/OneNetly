import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PayPalIpnController::paypalIpn
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
export const paypalIpn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paypalIpn.url(options),
    method: 'post',
})

paypalIpn.definition = {
    methods: ["post"],
    url: '/webhooks/paypal/ipn',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PayPalIpnController::paypalIpn
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
paypalIpn.url = (options?: RouteQueryOptions) => {
    return paypalIpn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PayPalIpnController::paypalIpn
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
paypalIpn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paypalIpn.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PayPalIpnController::paypalIpn
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
    const paypalIpnForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: paypalIpn.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PayPalIpnController::paypalIpn
 * @see app/Http/Controllers/PayPalIpnController.php:18
 * @route '/webhooks/paypal/ipn'
 */
        paypalIpnForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: paypalIpn.url(options),
            method: 'post',
        })
    
    paypalIpn.form = paypalIpnForm
const webhooks = {
    paypalIpn: Object.assign(paypalIpn, paypalIpn),
}

export default webhooks