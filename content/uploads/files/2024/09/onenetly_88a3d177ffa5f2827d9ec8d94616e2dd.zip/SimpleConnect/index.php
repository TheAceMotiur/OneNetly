<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SimpleConnect v1.0</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="contact-form-container">
    <h2>Contact Us</h2>

    <form action="process_form.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="phone">Phone Number (Optional):</label>
        <input type="tel" id="phone" name="phone">

        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>

        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="5" required></textarea>

        <button type="submit">Send Message</button>
    </form>
</div>

<!-- Footer -->
<footer>
    <p>Dev by <a href="https://onenetly.com" target="_blank">OneNetly</a></p>
</footer>

</body>
</html>
