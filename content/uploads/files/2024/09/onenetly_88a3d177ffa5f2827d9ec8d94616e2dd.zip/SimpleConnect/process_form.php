<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';  // Ensure this path is correct if using Composer

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize form inputs
    $name = filter_var(trim($_POST['name']), FILTER_SANITIZE_STRING);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $phone = filter_var(trim($_POST['phone']), FILTER_SANITIZE_STRING);
    $title = filter_var(trim($_POST['title']), FILTER_SANITIZE_STRING);
    $message = filter_var(trim($_POST['message']), FILTER_SANITIZE_STRING);

    // Validate required fields
    if (empty($name) || empty($email) || empty($title) || empty($message)) {
        echo "Error: All fields except Phone Number are required.";
        exit;
    }

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();                                      // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                  // Set the SMTP server to use (e.g., Gmail)
        $mail->SMTPAuth   = true;                             // Enable SMTP authentication
        $mail->Username   = 'your-email@gmail.com';            // SMTP username
        $mail->Password   = 'your-password';                   // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;    // Enable TLS encryption
        $mail->Port       = 587;                              // TCP port to connect to

        // Recipients
        $mail->setFrom($email, $name);  // Sender (form user)
        $mail->addAddress('your-email@example.com');  // Your email (recipient)

        // Content
        $mail->isHTML(false);  // Set email format to plain text
        $mail->Subject = "New Contact Form Submission: $title";
        $mail->Body    = "You have received a new message:\n\n"
                       . "Name: $name\n"
                       . "Email: $email\n"
                       . (!empty($phone) ? "Phone: $phone\n" : "")
                       . "Title: $title\n"
                       . "Message:\n$message\n";

        // Send email
        $mail->send();
        echo 'Message has been sent successfully!';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
