<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureGen: Password Generator</title>
    <meta name="description" content="Use SecureGen to generate a secure password. Simply input your desired password length, and SecureGen will do the rest!">
    <meta name="keywords" content="generate password, password generator, secure password, create password, SecureGen">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Generate a Secure Password</h2>
        <form action="generate_password.php" method="get">
            <label for="length">Password Length:</label>
            <input type="number" id="length" name="length" min="6" max="64" value="12">
            <br><br>
            <input class="btn" type="submit" value="Generate Password">
        </form>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> SecureGen - Developed by <a href="https://onenetly.com" target="_blank">OneNetly</a></p>
    </footer>
</body>
</html>
