<?php
// Function to generate a random password
function generatePassword($length = 12) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()';
    $charactersLength = strlen($characters);
    $randomPassword = '';

    for ($i = 0; $i < $length; $i++) {
        $randomPassword .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomPassword;
}

$passwordLength = 12;
if (isset($_GET['length']) && is_numeric($_GET['length'])) {
    $passwordLength = intval($_GET['length']);
}

if ($passwordLength < 6 || $passwordLength > 64) {
    echo "<p style='color:red;'>Error: Password length must be between 6 and 64 characters.</p>";
    exit;
}

$generatedPassword = generatePassword($passwordLength);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureGen: Your Generated Password</title>
    <meta name="description" content="SecureGen has generated your random password based on your custom parameters. Create secure passwords quickly and efficiently.">
    <meta name="keywords" content="generate password, secure password, random password, password generator, SecureGen">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Your Generated Password</h2>
        <p><strong>Password:</strong> <span class="password-box"><?php echo $generatedPassword; ?></span></p>
        <br>
        <a class="btn" href="form.php">Generate Another Password</a>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> SecureGen - Developed by <a href="https://onenetly.com" target="_blank">OneNetly</a></p>
    </footer>
</body>
</html>
