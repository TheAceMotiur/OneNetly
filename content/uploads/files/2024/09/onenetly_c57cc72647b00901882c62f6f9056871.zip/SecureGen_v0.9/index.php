<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureGen - Secure Password Generator</title>
    <meta name="description" content="SecureGen is a reliable and easy-to-use tool to generate strong, secure passwords. Protect your accounts with random passwords using SecureGen.">
    <meta name="keywords" content="password generator, secure password, random password, generate password, security tool, SecureGen">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to SecureGen</h1>
        <p>SecureGen is a simple, reliable password generator that helps you create strong, secure passwords in just a few clicks. Whether you need a password for personal or professional use, SecureGen makes it easy to generate random, secure passwords to protect your accounts.</p>
        
        <h2>Features:</h2>
        <ul>
            <li>Customize your password length (from 6 to 64 characters)</li>
            <li>Includes uppercase, lowercase, numbers, and special characters for maximum security</li>
            <li>Easy-to-use interface</li>
        </ul>

        <p>Click the button below to start generating secure passwords.</p>
        <a class="btn" href="form.php">Generate a Password Now</a>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> SecureGen - Developed by <a href="https://onenetly.com" target="_blank">OneNetly</a></p>
    </footer>
</body>
</html>
